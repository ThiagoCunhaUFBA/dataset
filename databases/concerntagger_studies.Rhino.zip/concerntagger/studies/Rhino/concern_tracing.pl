#!/usr/bin/perl

use strict;

select STDERR; $| = 1; # make STDERR unbuffered
select STDOUT; $| = 1; # make STDOUT unbuffered

# ------------------------------------------------------------
# Initialize local variables
# ------------------------------------------------------------

my $cmd = &get_emma_rhino_cmd();

# Stats
my $executed = 0;
my $skipped_not_section = 0;
my $skipped_no_concern = 0;
my $analyze_leaf_sections_only = 0;

# For internal testing/debugging
my $stop_after;
my $skip;
my $execute_test_cases = 1;
#$stop_after = 1;
#$skip = 3;

# Input files
my $test_dir                            = "mozilla\\js\\tests";
my $sec_2_concern_file 			= "rhino.sections.arff";
my $all_methods_file                    = "rhino.methods.arff";

# Output files
my $methods_to_test_cases_out_file 	= "rhino.methods_executed_by_unit_tests.arff";
my $methods_to_concerns_out_file 	= "rhino.methods_executed_by_concern.arff";
my $concerns_out_file 			= "rhino.concerns.arff";

my %method_2_test_cases;
my $test_case_path;
my %num_test_cases_for_concern;

# ------------------------------------------------------------
# Get the section->concern map
# ------------------------------------------------------------

my (%all_sec_2_concern) = &read_sec_2_concern_file($sec_2_concern_file);

# Obtain all or a subset of the sections

my (%sec_2_concern) = &get_section_to_concern_map(\%all_sec_2_concern);

# Output the concerns we are looking for

&output_concerns($concerns_out_file, \%sec_2_concern, \%all_sec_2_concern);

# ------------------------------------------------------------
# Get all the test cases in the ecma directories
# ------------------------------------------------------------

my @test_case_paths = &get_test_case_paths();

# For pretty printing

my $len_longest_test_case_path = &get_max_len(@test_case_paths);

# Initialize the method->test_cases map. This is updated after each test case
# is executed.

&update_method_2_test_cases_map($all_methods_file, "", \%method_2_test_cases, 0);

# ------------------------------------------------------------
# Execute each test case
# ------------------------------------------------------------

my $start_time = time;

print "Executing " . ($#test_case_paths+1) . " test cases...\n\n";

foreach $test_case_path (sort { &compare_test_cases } @test_case_paths)
{
	my ($test_suite, $test_category, $test_case_file) = ($test_case_path =~ /([^\\]*)\\([^\\]*)\\([^\\]*)$/);

	my ($section) = ($test_case_file =~ /^(\d+(\.\d+)*(-\d+)?n?)/);

	# Skip non-section test cases (e.g., regression tests)
	if ($section eq "")
	{
		print "Skipping $test_case_path: Not a section test case\n";
		++$skipped_not_section;
		next;
	}

	my $concern = &test_case_to_concern($test_case_file, \%sec_2_concern, \%all_sec_2_concern);

	# Skip test cases not associated with a concern. Can occur when
	# our concerns are low-level (eg, "5.4.2 - Arrays") but the test
	# case is high-level (eg, "5.4.js")
	if ($concern eq "")
	{
		print "Skipping $test_case_path: No associated concern\n";
		++$skipped_no_concern;
		next;
	}

	if (defined $skip && $skip-- > 0)
	{
		print "Skipping $test_case_path\n";
		next;
	}

	last if defined $stop_after && $executed >= $stop_after;

	printf("Executing %$len_longest_test_case_path" . "s -> %s\n", 
		$test_case_path, $concern);

	++$num_test_cases_for_concern{$concern};

	my $cmd2 = $cmd;

	if (-f "$test_dir\\$test_suite\\shell.js")
	{
		$cmd2 .= " -f $test_dir\\$test_suite\\shell.js";
	}

	if (-f "$test_dir\\$test_suite\\$test_category\\shell.js")
	{
		$cmd2 .= " -f $test_dir\\$test_suite\\$test_category\\shell.js";
	}

	my $test_case_dir = "$test_dir\\$test_suite\\$test_category";

	&execute_test_case($cmd2, \%method_2_test_cases, $test_case_dir, $test_case_file, "compiled");
	&execute_test_case($cmd2, \%method_2_test_cases, $test_case_dir, $test_case_file, "interpreted");

	++$executed;
}

print "\nUnit Test Elapsed Time: " . &get_elapsed_time($start_time) . "\n";

&output_methods2testcases($methods_to_test_cases_out_file, \%method_2_test_cases);

&output_methods2concerns($methods_to_concerns_out_file, \%method_2_test_cases, \%sec_2_concern,
	\%all_sec_2_concern, \%num_test_cases_for_concern);

print "\nTest Case Summary:\n\n";
printf("  %3d Section test cases associated with a concern\n", $executed);
printf("  %3d Section test cases not associated with a concern\n", $skipped_no_concern);
printf("  %3d Non-section test cases\n", $skipped_not_section);
printf("  %3d Total test cases\n", ($executed + $skipped_no_concern + $skipped_not_section));

print "\nTotal Elapsed Time: " . &get_elapsed_time($start_time) . "\n";

exit(0);

#---------------------------- SUBROUTINES --------------------------------

sub execute_test_case
{
	my($cmd, $method_2_test_cases, $test_case_dir, $test_case_file, $opt) = @_;

	# Remove the .js file extension
	my ($test_case) = ($test_case_file =~ /(.*)\.js/);

	my $arff_out_path = "$test_case_dir\\$test_case.$opt.arff";

	my $test_output_path = "$test_case_dir\\$test_case.$opt.out";

	$cmd .= " -f $test_case_dir\\$test_case_file";

	$cmd =~ s/REPLACE_OUT_FILE/$arff_out_path/;

	if ($opt eq "compiled")
	{
		$cmd =~ s/REPLACE_OPT/0/;
	}
	else
	{
		die unless $opt eq "interpreted";
		$cmd =~ s/REPLACE_OPT/-1/;
	}

	# Print out the command we are about to run
	#print "\n$cmd > $test_output_path 2<&1\n";

	# So we don't run the unit test multiple times redundantly.
	# Make sure you erase the arff and out files if you want to
	# re-run the test.
	if ($execute_test_cases)
	{
		if (!-f $test_output_path || !-f $arff_out_path)
		{
			`echo $cmd > $test_output_path && $cmd >> $test_output_path 2<&1`;
		}
	}

	&update_method_2_test_cases_map($arff_out_path, $test_case, $method_2_test_cases, 1);
}

sub output_concerns
{
	my($file, $sec_2_concern, $all_sec_2_concern) = @_;
	my($section);

	open(OUT, ">$file") or
		die "failed to create ARFF output file '$file': $!\n";

	print "Writing concern list to file '$file'...\n\n";

	print OUT "\@RELATION \"Rhino Concerns\"\n\n";
	print OUT "\@ATTRIBUTE concern-name string\n\n";
	print OUT "\@DATA\n";

	foreach $section (sort { &compare_test_cases } keys %{$sec_2_concern})
	{
		my $concern = &section_to_concern($section, $all_sec_2_concern);
		
		print OUT "\"$concern\"\n";
	}

	close OUT;
}

sub output_methods2concerns
{
	my($file, $method_2_test_cases, $sec_2_concern, $all_sec_2_concern, $num_test_cases_for_concern) = @_;
	my($key);
	my(%histo);

	open(OUT, ">$file") or
		die "failed to create ARFF output file '$file': $!\n";

	print "\nWriting consolidated coverage data to file '$file'...\n";

	print OUT "\@RELATION \"Rhino Test Suite Coverage\"\n\n";
	print OUT "\@ATTRIBUTE entity-name string\n";
	print OUT "\@ATTRIBUTE entity-type {method}\n";
	print OUT "\@ATTRIBUTE concern-list string\n\n";
	print OUT "\@DATA\n";

	my $method_count = 0;
	my $concern;

	my @concerns_exercised = ();

	foreach $key (sort keys %{$method_2_test_cases})
	{
		++$method_count;

		my $test_case_list = $method_2_test_cases->{$key};

		# If the list is empty, the method was never exercised by
		# a test case

		if (length($test_case_list) == 0)
		{
			++$histo{0};
			print OUT "\"$key\",method,\"\"\n";
			next;
		}

		# Convert comma-delimited list of test cases to test case array
		my @test_cases = split(",", $test_case_list);

		# Convert test case (really, "section") names to concern names,
		# eg "3.2.4-1.js" -> "3.2.4 - Arrays"

		my (@concerns) = &test_cases_to_concerns(\@test_cases, $sec_2_concern, $all_sec_2_concern);

		foreach $concern (@concerns)
		{
			push(@concerns_exercised, $concern) unless &has_element(\@concerns_exercised, $concern);
		}

		++$histo{scalar(@concerns)};

		my $concern_list = join(",", @concerns);
		
		print OUT "\"$key\",method,\"$concern_list\"\n";

		# Progress bar
		print "\t...Processed $method_count methods...\n" if $method_count % 100 == 0;
	}

	close OUT;

	my $section;
	my @concerns_not_exercised = ();
	foreach $section (keys %{$sec_2_concern})
	{
		my $concern_name = &section_to_concern($section, $all_sec_2_concern);

		if (!&has_element(\@concerns_exercised, $concern_name))
		{
			push(@concerns_not_exercised, $concern_name);
		}
	}

	print "\nCoverage Summary:\n\n";

	my $exercised_methods = $method_count - $histo{0};
	printf("  Total Methods     : %4d\n", $method_count);
	printf("  Exercised Methods : %4d (%.02f%%)\n", 
		$exercised_methods, ($exercised_methods/$method_count)*100);
	printf("  Sharing Clusters  : %4d\n\n", scalar(keys(%histo)));

	my(%avg);

	foreach $key (keys %histo)
	{
		$avg{$key} = ($histo{$key} / $method_count) * 100;
	}

	my($running_count) = 0;

	foreach $key (sort { $a <=> $b } keys %histo)
	{
		printf("  %4d (%4.1f%%) methods exercised by %3d concerns\n", 
			$histo{$key}, $avg{$key}, $key);
		
		$running_count += $histo{$key};
	}

	print "\nConcern Summary:\n\n";
	print "  Total Concerns: " . scalar(values(%sec_2_concern)) . "\n";
	print "\n  Concerns Exercised: " . scalar(@concerns_exercised) . "\n";
	foreach $concern (sort { &compare_test_cases } @concerns_exercised)
	{
		printf("    $concern (exercised by %2d test cases)\n", 
			$num_test_cases_for_concern->{$concern});
	}

	print "\n  Concerns Not Exercised: " . scalar(@concerns_not_exercised) . "\n";
	print "    " . join("\n    ", sort { &compare_test_cases } @concerns_not_exercised) . "\n";

	die "$method_count != $running_count" if $method_count != $running_count;
}

sub output_methods2testcases
{
	my($file, $method_2_test_cases) = @_;
	my ($key);

	open(OUT, ">$file") or
		die "failed to create ARFF output file '$file': $!\n";

	print "\nWriting consolidated coverage data to file '$file'...\n";

	print OUT "\@RELATION \"Rhino Test Suite Coverage\"\n\n";
	print OUT "\@ATTRIBUTE method-name string\n";
	print OUT "\@ATTRIBUTE test-case-list string\n\n";
	print OUT "\@DATA\n";

	foreach $key (sort keys %{$method_2_test_cases})
	{
		print OUT "\"$key\",\"$method_2_test_cases->{$key}\"\n";
	}

	close OUT;
}

sub read_sec_2_concern_file
{
	my ($file) = @_;
	my (%sec_2_concern);

        open (FILE, $file) or
           die "failed to open section-to-concern file '$file': $!\n";

	my $data_started = 0;

	while(<FILE>)
	{
		if ($data_started)
		{
			my ($section,$concern) = ($_ =~ /^(.*),\"(.*)\"$/);
			print "Invalid section found in $file: $_" if length($section) == 0;
			print "Invalid concern found in $file: $_" if length($concern) == 0;
			$sec_2_concern{$section} = $concern;
		}
		elsif ($_ =~ /^\@DATA$/)
		{
			$data_started = 1;
		}
	}

        close (FILE);

	return %sec_2_concern;
}

sub get_section_to_concern_map
{
	my($all_sec_2_concern) = @_;

	if ($analyze_leaf_sections_only)
	{
		# rhino.sections.arff relates ALL the section numbers in the Rhino 
		# specification to concern names (e.g. 7.1 -> "Unicode Format-Control Characters")
		#
		# However, we are only performing the mapping of the lowest level subsections
		# (ie, the leaves, the section frontier)

		return &get_section_leaves($all_sec_2_concern);
	}
	else
	{
		return %{$all_sec_2_concern};
	}
}

sub test_cases_to_concerns
{
	my($test_cases, $sec_2_concern, $all_sec_2_concern) = @_;
	my($test_case);

	my(@concerns) = ();

	foreach $test_case (sort { &compare_test_cases } @{$test_cases})
	{
		my($concern) = &test_case_to_concern($test_case, $sec_2_concern, $all_sec_2_concern);
		if (length($concern) > 0)
		{
			push(@concerns, $concern) unless &has_element(\@concerns, $concern);
		}
	}

	return @concerns;
}


#
# Tries to find the most specific concern for the test case
#
sub test_case_to_concern
{
	my($test_case, $sec_2_concern, $all_sec_2_concern) = @_;

	# We ignore the trailing dashes which represent subcases
	# for a particular subsection

	my ($section) = ($test_case =~ /^(\d+(\.\d+)*)(-\d+)?n?/);

	# Get each section part, eg 3.2.4 -> (3 2 4)

	my (@section_parts) = split(/\./, $section);
	die "Invalid section: $section $#section_parts" if $#section_parts == -1;

	# Keep trying higher level sections until we find a match, eg 3.2.4, 3.2, 3

	while ($#section_parts > -1)
	{
		#print "Trying section: $section\n";

		if (defined $sec_2_concern->{$section})
		{
			# For readability, prefix the concern name with the
			# section, eg "3.2.3 - Arrays"

			my $concern = &section_to_concern($section, $all_sec_2_concern);

			#print "Matched: $concern\n";

			return $concern;
		}

		pop(@section_parts);
		($section) = join(".", @section_parts);
	}

	#print "No Match: $test_case\n";
	return "";
}

sub section_to_concern
{
	my($section, $all_sec_2_concern) = @_;

	my ($tmp, $sec_level, $current_section);

	$tmp = "";
	$current_section = "";

	my (@section_levels) = split(/\./, $section);
	foreach $sec_level (@section_levels)
	{
		$current_section .= "." if length($current_section) > 0;
		$current_section .= $sec_level;

		$tmp .= "/" if length $tmp > 0;
		$tmp .= "$current_section - " . $all_sec_2_concern->{$current_section};
	}


	return $tmp;
}

sub update_method_2_test_cases_map
{
	my($file, $test_case, $method_2_test_cases, $require_method_to_exist) = @_;

        if (!open (FILE, $file))
	{
		print STDERR "failed to open Emma ARFF output file '$file': $!\n";
		return;
	}

	my $data_started = 0;

	while(<FILE>)
	{
		if ($data_started)
		{
			my ($method_name) = ($_ =~ /^\"(.*)\"$/);
			print "Invalid method found in $file: $_" if length($method_name) == 0;

			my $test_case_list = $method_2_test_cases->{$method_name};
			$test_case_list .= "," if length($test_case_list) > 0;
			$test_case_list .= $test_case;

 			if ($require_method_to_exist && !defined $method_2_test_cases->{$method_name})
			{
				print "Method '$method_name' exercised by test case '$test_case' is is unknown. ";
				print "Is $all_methods_file up-to-date?\n"
			}

			$method_2_test_cases->{$method_name} = $test_case_list;
		}
		elsif ($_ =~ /^\@DATA$/)
		{
			$data_started = 1;
		}
	}

        close (FILE);
}

sub compare_test_cases
{
	return &normalize_test_case_name($a) cmp &normalize_test_case_name($b);
}

sub normalize_test_case_name
{
	my($name) = $_[0];

	my $zero = "0";
	my $pointzero = ".00";
	my $pointzeropointzero = ".00.00";

	# Remove path portion: "ecma/Arrays/7.5.1-1-n.js" -> "7.5.1-1-n.js"
	$name =~ s/.*\\([^\\]*)$/$1/;

	# Convert single digits to double: "7.5.1-1-n.js" -> "07.05.01-01-n.js"
	$name =~ s/^(\d)$/$zero$1$2/g;
	$name =~ s/^(\d)([\.-])/$zero$1$2/g;
	$name =~ s/([\.-])(\d)$/$1$zero$2/g;
	$name =~ s/([\.-])(\d)([\.-])/$1$zero$2$3/g;
	$name =~ s/([\.-])(\d)([\.-])/$1$zero$2$3/g;

	# Convert missing digits to double: "07.05" -> "07.05.00"
	$name =~ s/^(\d+\.\d+)([^\.\d])/$1$pointzero$2/;
	$name =~ s/^(\d+\.\d+)$/$1$pointzero/;
	$name =~ s/^(\d+)([^\.\d])/$1$pointzeropointzero$2/;
	$name =~ s/^(\d+)$/$1$pointzeropointzero/;

	#print "$name\n";

	return $name;
}

sub get_elapsed_time
{
	my ($start_time) = @_;

	my $exec_time = (time - $start_time);
	my $exec_hours = int($exec_time / 60 / 60);
	$exec_time -= $exec_hours * 60 * 60;
	my $exec_mins = int($exec_time / 60);
	$exec_time -= $exec_mins * 60;
	my $exec_secs = ($exec_time % 60);

	if ($exec_hours > 0) 
	{
		return "$exec_hours hours, $exec_mins minutes, " . "$exec_secs seconds";
	} 
	elsif ($exec_mins > 0) 
	{
		return "$exec_mins minutes, $exec_secs seconds";
	} 
	else
	{
		return "$exec_secs seconds";
	}
}

sub has_element
{
	my($array, $val) = @_;

	my (@matches) = grep($_ eq $val, @{$array});
	return ($#matches > -1);
}

sub get_section_leaves
{
	my ($all_sec_2_concern) = @_;
	my (%leaves);
	my $key;

	foreach $key (sort keys %{$all_sec_2_concern})
	{
		if (!defined($all_sec_2_concern->{"$key.1"}))
		{
			$leaves{$key} = $all_sec_2_concern->{$key};
		}
	}

	return %leaves;
}

#
# given a directory, return an array of all subdirectories
#
sub get_subdirs {
    my ($dir)  = @_;
    my @subdirs;

    if (!($dir =~ /\/$/)) {
        $dir = $dir . "/";
    }

    opendir (DIR, $dir) || die ("couldn't open directory $dir: $!");
    my @testdir_contents = readdir(DIR);
    closedir(DIR);

    foreach (@testdir_contents) {
        if ((-d ($dir . $_)) && ($_ ne 'CVS') && ($_ ne '.') && ($_ ne '..')) {
            @subdirs[$#subdirs + 1] = $_;
        }
    }

    return @subdirs;
}

#
# given a directory, return an array of all the js files that are in it.
#
sub get_js_files {
    my ($test_subdir) = @_;
    my (@js_file_array, @subdir_files);

    opendir (TEST_SUBDIR, $test_subdir) || die ("couldn't open directory " .
                                                "$test_subdir: $!");
    @subdir_files = readdir(TEST_SUBDIR);
    closedir( TEST_SUBDIR );

    foreach (@subdir_files) {
        if ($_ =~ /\.js$/) {
            $js_file_array[$#js_file_array+1] = $_;
        }
    }

    return @js_file_array;
}

sub get_test_case_paths
{
	my @test_suites = ( "ecma", "ecma_2", "ecma_3" );

	my $test_suite;
	my $test_category;
	my $test_case_file;

	my @test_case_paths = ();

	foreach $test_suite (@test_suites)
	{
		foreach $test_category (&get_subdirs("$test_dir\\$test_suite"))
		{
			foreach $test_case_file (&get_js_files("$test_dir\\$test_suite\\$test_category"))
			{
				# Skip helper files
				next if $test_case_file eq "browser.js" || $test_case_file eq "shell.js";

				my $test_case_path = "$test_dir\\$test_suite\\$test_category\\$test_case_file";
	
				push(@test_case_paths, $test_case_path);
			}
		}
	}

	return @test_case_paths;
}

sub get_emma_rhino_cmd
{
	my $cmd = "java";

	# Emma command
	$cmd .= " -classpath ..\\..\\emma-2.0.5312\\out\\emma.jar";
	$cmd .= " emmarun";
	$cmd .= " -f"; 			                   # Full metadata (needed?)
	$cmd .= " -r arff"; 		                   # Generate ARFF file
	$cmd .= " -sp mozilla\\js\\rhino\\src"; 	   # Location of source files
	$cmd .= " -Dreport.out.file REPLACE_OUT_FILE";     # Location of ARFF output file

	# Rhino test case command
	$cmd .= " -classpath mozilla\\js\\rhino\\build\\classes";
	$cmd .= " org.mozilla.javascript.tools.shell.Main";
	$cmd .= " -opt REPLACE_OPT"; # Optimization: 0 compiled, -1 interpreted
	$cmd .= " -f mozilla\\js\\tests\\shell.js";

	return $cmd;
}

sub get_max_len
{
	my $len = 0;
	foreach $_ (@_)
	{
		$len = length($_) if length($_) > $len;
	}

	return $len;
}
