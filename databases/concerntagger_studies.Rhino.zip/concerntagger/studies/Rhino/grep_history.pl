use strict;

die "Usage: $! <path>\n" if $#ARGV < 0;

my ($path) = @ARGV[0];

my $shell_file_mask = "*.java";

# Convert shell pattern to Perl pattern
my $perl_file_mask = $shell_file_mask;
$perl_file_mask =~ s/\./\\./g;
$perl_file_mask =~ s/\*/.*/g;
$perl_file_mask .= "\$";

my $CVSROOT = "-d:pserver:anonymous\@cvs-mirror.mozilla.org:/cvsroot";
my $cache_dir = "source_file_version_cache";

#&cache_dir($path, $perl_file_mask);
&search_cache($path, $shell_file_mask, $perl_file_mask);

sub search_cache
{
	my ($pattern, $shell_file_mask, $perl_file_mask) = @_;

	opendir(DIR, $cache_dir) || die("Cannot open directory");
	my (@files) = readdir(DIR);
	closedir(DIR);

	my %rev_map;

	my $file;
	foreach $file (sort { &cmp_rev_files($a, $b) } grep(/$perl_file_mask/, @files))
	{
		next if $file eq "." || $file eq "..";

		#print "$file\n";

		my ($filename, $revision, $ext) = ($file =~ /^([^\.]*)\.(.*)\.([^\.]*)$/);

		$filename = "$filename.$ext";

		push(@{$rev_map{$filename}}, $revision);

		#print "$filename-$revision-$ext\n";
	}

	my (@matches) = `grep $pattern $cache_dir\\$shell_file_mask`;

	my %present;
	my %missing;	

	my $match;
	foreach $match (@matches)
	{
		#print $match;

		my ($filename, $revision, $ext) = ($match =~ /^$cache_dir\\([^\.:]*)\.([^:]*)\.([^\.:]*):/);

		$filename = "$filename.$ext";

		my $found = 0;

		foreach $file (keys %rev_map)
		{
			if ($file =~ /^$filename$/i)
			{
				$filename = $file;
				$found = 1;
				last;
			}
			
		}

		die "Failed to find file: $filename" if !$found;

		push(@{$present{$filename}}, $revision);
	}

	foreach $file (sort keys %present)
	{
		my (@revs_all) = sort { &cmp_revs($a, $b) } @{$rev_map{$file}};
		my (@revs_present) = sort { &cmp_revs($a, $b) } @{$present{$file}};

		my $first_present_rev = $revs_present[0];
		my $last_present_rev = $revs_present[$#revs_present];

		my $i;

		my $rev;

		print "$file\n";

		for($i = 0; $i < $#revs_all; ++$i)
		{
			$rev = $revs_all[$i];

			if ($i == 0 && $rev ne $first_present_rev)
			{
				print "\t$first_present_rev - ADDED\n";
			}

			my $cmp = &cmp_revs($last_present_rev, $rev);
			if ($cmp < 0)
			{
				print "\t$rev - REMOVED\n";
				last;
			}
		}
	}
}

sub min_rev
{
	return &cmp_revs(@_[0], @_[1]) < 0 ? @_[0] : @_[1];
}

sub max_rev
{
	return &cmp_revs(@_[0], @_[1]) > 0 ? @_[0] : @_[1];
}

sub cmp_rev_files
{
	my ($fileA, $revA) = (@_[0] =~ /^($cache_dir\/)?([^\.]*)\.(.*)\.[^\.]*/);
	my ($fileB, $revB) = (@_[1] =~ /^($cache_dir\/)?([^\.]*)\.(.*)\.[^\.]*/);

	if (length $fileA == 0 || length $fileB == 0)
	{
		return @_[0] cmp @_[1];
	}
	elsif ($fileA ne $fileB)
	{
		return $fileA cmp $fileB;
	}
	else
	{
		return &cmp_revs($revA, $revB);
	}
}

sub cmp_revs
{
	my (@partsA) = split(/\./, @_[0]);
	my (@partsB) = split(/\./, @_[1]);

	my $i;

	for($i = 0; $i <= $#partsA && $i <= $#partsB; ++$i)
	{
		my $numA = $partsA[$i];
		my $numB = $partsB[$i];

		#print "$numA - $numB\n";
		
		return ($numA - $numB) if ($numA != $numB);
	}

	return $#partsA - $#partsB;
}

sub cache_dir
{
	my ($dir, $file_mask) = @_;

	my (@entries) = `cvs $CVSROOT ls -e $dir`;

	my $entry;

	foreach $entry (@entries)
	{
		chop $entry;

		next if $entry =~ /Listing module/ || length($entry) == 0;

		my ($subdir) = ($entry =~ /^D\/([^\/]*)/);
		if (length($subdir) > 0)
		{
			&cache_dir("$dir/$subdir", $file_mask);
		}
		else
		{
			my ($file) = ($entry =~ /^\/([^\/]*)/);

			if ($file =~ /^$file_mask$/)
			{
				&cache_file($dir, $file);
			}
		}
	}
}

sub cache_file
{
	my ($dir, $file) = @_;

	print "Caching $file\n";

	my $cmd = "cvs $CVSROOT log $dir/$file";

	#print "$cmd\n";
	my (@lines) = `$cmd`;

	my $line;

	foreach $line (@lines)
	{
		chop $line;
		my ($revision) = ($line =~ /^revision (.*)/);
		next if length($revision) == 0;

		&cache_revision($dir, $file, $revision);
	}
}

sub cache_revision
{
	my ($dir, $file, $revision) = @_;

	my ($filename, $ext) = ($file =~ /(.*)\.([^\.]*)$/);

	my $revision_file = "$cache_dir\\$filename.$revision.$ext";

	return if -f $revision_file;

	mkdir $cache_dir if !-d $cache_dir;

	my $cmd = "cvs $CVSROOT checkout -p -r $revision $dir/$file";
	`$cmd > $revision_file 2>nul`;
}
