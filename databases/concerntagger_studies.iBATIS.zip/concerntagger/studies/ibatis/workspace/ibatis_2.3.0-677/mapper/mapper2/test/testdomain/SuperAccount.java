package testdomain;

import java.io.Serializable;

public class SuperAccount extends Account implements Serializable {
}
