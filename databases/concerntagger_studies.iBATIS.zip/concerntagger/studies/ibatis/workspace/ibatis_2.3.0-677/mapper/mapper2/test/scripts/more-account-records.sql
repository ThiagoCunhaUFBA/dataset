

DELETE ACCOUNT;

INSERT INTO ACCOUNT VALUES(1,'Clinton', 'Begin', 'clinton.begin@ibatis.com');
INSERT INTO ACCOUNT VALUES(2,'Jim', 'Smith', 'jim.smith@somewhere.com');
INSERT INTO ACCOUNT VALUES(3,'Elizabeth', 'Jones', null);
INSERT INTO ACCOUNT VALUES(4,'Bob', 'Jackson', 'bob.jackson@somewhere.com');
INSERT INTO ACCOUNT VALUES(5,'&manda', 'Goodman', null);
INSERT INTO ACCOUNT VALUES(6,'Rick', 'Maximum', 'rick@ibatis.com');
INSERT INTO ACCOUNT VALUES(7,'Steve', 'Todor', 'steve@somewhere.com');
INSERT INTO ACCOUNT VALUES(8,'Elizabeth', 'Samson', null);
INSERT INTO ACCOUNT VALUES(9,'Robert', 'Johnson', 'blahblah@somewhere.com');
INSERT INTO ACCOUNT VALUES(10,'June', 'Willis', null);

