package testdomain;

/**
 * Created by IntelliJ IDEA.
 * User: cbegin
 * Date: May 14, 2005
 * Time: 1:40:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class Magazine extends Document {

  private String city;

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

}
